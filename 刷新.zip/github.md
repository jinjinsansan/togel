repo: jinjinsansan/togel
branch: main
path: web/src

## Last sync
date: 2026-08-07T11:35:39Z

### Updated in this project
- P1全画面（トップLP／診断フロー／ミスマッチ結果／診断結果／マイページ／地雷回避ガイド）をHTMLプロトタイプ化（モバイル390・PC1280切替）
- P2レイアウト指示＋OGP 1200×630テンプレート＋P3トークン適用方針を作成
- デザイントークン（tokens/togel-tokens.json, tokens/tailwind.config.snippet.js）を体系化
- ロゴ3案・キーメッセージ3案・プライマリピンク #E91E63→#FF2E74 の提案

## Screen map
| 画面 | 参照した repo ファイル |
|---|---|
| Togel トップLP.dc.html | web/src/app/page.tsx, web/src/app/globals.css, web/tailwind.config.ts |
| Togel 診断フロー.dc.html | web/src/data/questions.ts, web/src/types/diagnosis.ts, web/src/components/diagnosis/ |
| Togel ミスマッチ結果.dc.html | web/src/lib/personality/definitions.ts, web/src/lib/personality/mismatch-narrative.ts, web/src/types/diagnosis.ts |
| Togel 診断結果.dc.html | web/src/app/result/page.tsx, web/src/lib/personality/definitions.ts |
| Togel マイページ.dc.html | web/src/app/mypage/page.tsx, web/src/components/certificate/ |
| Togel 地雷回避ガイド.dc.html | web/src/lib/personality/mismatch-narrative.ts |
| Togel P2画面 レイアウト指示.dc.html | web/src/app/about/, types/, login/, components/age-gate.tsx, layout/site-header.tsx, site-footer.tsx |
| Togel デザイントークン.dc.html | web/src/app/globals.css, web/tailwind.config.ts, web/src/components/ui/ |
| Togel ロゴ案.dc.html | web/src/components/brand/togel-mark.tsx |
